var books = [{title: "Starting Out with C++ from Control Structures to Objects",
              newPrice: 167.10,
              usedPrice: 123.10,
              key: "proBook"},
              {title: "Calculus Single Variable",
              newPrice: 188.75,
              usedPrice: 141.60,
              key: "calcBook"},
              {title: "Physics for Scientists and Engineers",
              newPrice: 161.25,
              usedPrice: 120.95,
              key: "physBook"}];
var pageTitles = ["ProgrammingFundamentals", "SingleVariableCalculus1", "Physics1"];
