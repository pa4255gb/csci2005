//Used for testing log in page
var dummyAccountCreds = [{username: "Shelby", password: "cv8513vq"},
                        {username: "Keith", password: "pa4255gb"},
                        {username: "Tom", password: "wq3570is"}];
