//Suggestions for logIn - Shelby
//Validate username and password >>> data.js
//Go to myAccount.html if creds match >>> use window.location.assign();
//Put submitted username into local storage
//if window.localStorage.getItem("user") != null
//bypass logIn.html and go to myAccount.html
//Code to populate myAccount.html with data from submitted user >>> might want to put this in a
//separate js file.
